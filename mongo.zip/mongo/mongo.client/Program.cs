﻿using System;
using System.Collections.Generic;
using MongoDB.Bson;
using MongoDB.Driver;
using System.Threading;
using ATI.Oasis.BusClient.Entities;

namespace mongo.client
{
    class Program
    {


        static void Main(string[] args)
        {
            var connectionString = "mongodb://esb-dev1.dev.local:27017";
            var client = new MongoClient(connectionString);
            IMongoDatabase db = client.GetDatabase("Oasis");
            var collection = db.GetCollection<BsonDocument>("messages");
            int messageCount = 0;

            while (messageCount < 50000)
            {

                Message varMessage = new Message();
                varMessage.CorrelationId = Guid.NewGuid().ToString();
                varMessage.PayloadData = "Hello World - " + messageCount.ToString();
                varMessage.PayloadVersion = "1.0";
                var author1 = new BsonDocument
        {
               varMessage.ToBsonDocument()
                };

                var authors = new List<BsonDocument>();
                authors.Add(author1);

                collection.InsertMany(authors);
                messageCount++;
                Console.WriteLine("Message Inserted : " + messageCount.ToString());
              
            }

            DisplayDatabaseNames();

            Console.ReadLine();

            DisplayDocuments();
            Console.ReadLine();
        }

        private static void  DisplayDatabaseNames()
        {
            var connectionString = "mongodb://esb-dev1.dev.local:27017";
            var client = new MongoClient(connectionString);
            try
            {
                using (var cursor =  client.ListDatabases())
                {
                     cursor.ForEachAsync(document => Console.WriteLine(document.ToString()));
                }
            }
            catch
            {
                //Write your own code here to handle exceptions
            }
            return ;
        }

        static async void DisplayDocuments()
        {
            var connectionString = "mongodb://esb-dev1.dev.local:27017";
            var client = new MongoClient(connectionString);
            IMongoDatabase db = client.GetDatabase("Oasis");

            var collection = db.GetCollection<BsonDocument>("messages");

            using (IAsyncCursor<BsonDocument> cursor = await collection.FindAsync(new BsonDocument()))
            {
                while (await cursor.MoveNextAsync())
                {
                    IEnumerable<BsonDocument> batch = cursor.Current;
                    foreach (BsonDocument document in batch)
                    {
                        Console.WriteLine(document);
                        Console.WriteLine();
                    }
                }
            }
            return;
        }
    }
}
